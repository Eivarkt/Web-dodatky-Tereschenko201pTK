const ProductService = require('../../business/productService');

const productService = new ProductService();

exports.list = async (req, res) => {
  const products = await productService.list();
  res.render('products', {
    title: 'Товари',
    products,
    canEdit: res.locals.isAdmin
  });
};

exports.newForm = async (req, res) => {
  res.render('product_form', {
    title: 'Додати товар',
    isEdit: false,
    product: {
      image: '/static/assets/tee.jpg'
    }
  });
};

exports.create = async (req, res) => {
  try {
    await productService.create(req.body);
    res.redirect('/products');
  } catch (e) {
    res.status(400).render('product_form', {
      title: 'Додати товар',
      isEdit: false,
      error: e.message,
      product: { ...req.body }
    });
  }
};

exports.editForm = async (req, res) => {
  const product = await productService.get(req.params.id);
  if (!product) {
    return res.status(404).render('404', {
      title: 'Товар не знайдено',
      message: 'Такого товару не існує.'
    });
  }
  return res.render('product_form', {
    title: 'Редагувати товар',
    isEdit: true,
    product
  });
};

exports.update = async (req, res) => {
  try {
    await productService.update(req.params.id, req.body);
    res.redirect('/products');
  } catch (e) {
    res.status(400).render('product_form', {
      title: 'Редагувати товар',
      isEdit: true,
      error: e.message,
      product: { ...req.body, id: req.params.id }
    });
  }
};

exports.remove = async (req, res) => {
  await productService.remove(req.params.id);
  res.redirect('/products');
};
