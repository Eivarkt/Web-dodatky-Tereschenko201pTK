const UserService = require('../../business/userService');

const userService = new UserService();

exports.list = async (req, res) => {
  const users = await userService.list();
  res.render('users', {
    title: 'Користувачі',
    users
  });
};

exports.newForm = async (req, res) => {
  res.render('user_form', {
    title: 'Додати користувача',
    isEdit: false,
    user: { role: 'user' }
  });
};

exports.create = async (req, res) => {
  try {
    await userService.create(req.body);
    res.redirect('/users');
  } catch (e) {
    res.status(400).render('user_form', {
      title: 'Додати користувача',
      isEdit: false,
      error: e.message,
      user: { ...req.body }
    });
  }
};

exports.editForm = async (req, res) => {
  const user = await userService.get(req.params.id);
  if (!user) {
    return res.status(404).render('404', {
      title: 'Користувача не знайдено',
      message: 'Такого користувача не існує.'
    });
  }
  return res.render('user_form', {
    title: 'Редагувати користувача',
    isEdit: true,
    user
  });
};

exports.update = async (req, res) => {
  try {
    await userService.update(req.params.id, req.body);
    res.redirect('/users');
  } catch (e) {
    res.status(400).render('user_form', {
      title: 'Редагувати користувача',
      isEdit: true,
      error: e.message,
      user: { ...req.body, id: req.params.id }
    });
  }
};

exports.remove = async (req, res) => {
  await userService.remove(req.params.id);
  res.redirect('/users');
};
