const UserService = require('../../business/userService');

const userService = new UserService();

exports.showLogin = (req, res) => {
  if (req.session?.isAdmin) return res.redirect('/');
  res.render('login', { title: 'Вхід' });
};

exports.login = async (req, res) => {
  try {
    const { username, password } = req.body;
    const user = await userService.authenticate(username, password);
    if (!user) {
      return res.status(401).render('login', {
        title: 'Вхід',
        error: 'Невірний логін або пароль.'
      });
    }

    req.session.isAdmin = user.role === 'admin';
    req.session.userId = user.id;
    req.session.username = user.username;

    return res.redirect('/');
  } catch (e) {
    return res.status(500).render('login', {
      title: 'Вхід',
      error: 'Помилка сервера. Спробуйте ще раз.'
    });
  }
};

exports.logout = (req, res) => {
  req.session.destroy(() => {
    res.redirect('/');
  });
};

exports.requireAdmin = (req, res, next) => {
  if (req.session?.isAdmin) return next();
  return res.redirect('/login');
};
