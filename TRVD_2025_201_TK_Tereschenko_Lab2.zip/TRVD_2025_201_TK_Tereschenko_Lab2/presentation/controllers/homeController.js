const ProductService = require('../../business/productService');

const productService = new ProductService();

exports.index = async (req, res) => {
  const products = await productService.list();
  const featured = products.slice(0, 3);
  const featuredFirst = featured[0] || null;

  res.render('index', {
    title: 'Loyalty Path — Преміум одяг',
    kicker: 'Нові надходження — Колекція 2025',
    headline: 'Стриманий преміум для людей, що прагнуть більшого',
    desc:
      'Виробництво невеликими партіями. Тверда увага до деталей. Одяг, що працює на ваш імідж та дисципліну.',
    featured,
    featuredFirst
  });
};
