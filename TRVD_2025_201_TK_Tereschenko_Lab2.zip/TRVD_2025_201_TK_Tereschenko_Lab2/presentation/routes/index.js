const express = require('express');

const homeController = require('../controllers/homeController');
const authController = require('../controllers/authController');
const userController = require('../controllers/userController');
const productController = require('../controllers/productController');

const router = express.Router();

// Home
router.get('/', homeController.index);

// Auth
router.get('/login', authController.showLogin);
router.post('/login', authController.login);
router.post('/logout', authController.logout);

// Users CRUD
router.get('/users', userController.list);
router.get('/users/new', userController.newForm);
router.post('/users', userController.create);
router.get('/users/:id/edit', userController.editForm);
router.post('/users/:id', userController.update);
router.post('/users/:id/delete', userController.remove);

// Products CRUD
router.get('/products', productController.list);
router.get('/products/new', authController.requireAdmin, productController.newForm);
router.post('/products', authController.requireAdmin, productController.create);
router.get('/products/:id/edit', authController.requireAdmin, productController.editForm);
router.post('/products/:id', authController.requireAdmin, productController.update);
router.post('/products/:id/delete', authController.requireAdmin, productController.remove);

module.exports = router;
