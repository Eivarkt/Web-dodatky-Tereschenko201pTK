const express = require('express');
const mustacheExpress = require('mustache-express');
const session = require('express-session');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// View engine (server-side templating)
app.engine('mustache', mustacheExpress());
app.set('view engine', 'mustache');
app.set('views', path.join(__dirname, 'presentation', 'views'));

// Static files
app.use('/static', express.static(path.join(__dirname, 'public')));

// Body parsing (for HTML forms)
app.use(express.urlencoded({ extended: true }));

// Session (for simple admin login demo)
app.use(
  session({
    secret: 'trvd-lab2-demo-secret',
    resave: false,
    saveUninitialized: false,
  })
);

// Make session flags available to templates
app.use((req, res, next) => {
  res.locals.isAdmin = req.session?.isAdmin === true;
  res.locals.student = 'Терещенко Є. О. | 201-пТК';
  next();
});

// Routes
const routes = require('./presentation/routes');
app.use('/', routes);

// 404
app.use((req, res) => {
  res.status(404).render('404', {
    title: 'Сторінку не знайдено',
    message: 'Схоже, ви перейшли на адресу, якої не існує.'
  });
});

app.listen(PORT, () => {
  console.log(`Server running: http://localhost:${PORT}`);
});
