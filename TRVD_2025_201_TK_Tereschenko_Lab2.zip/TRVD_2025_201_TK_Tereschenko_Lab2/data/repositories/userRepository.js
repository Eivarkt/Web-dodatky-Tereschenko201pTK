const path = require('path');
const JsonFileRepository = require('./jsonFileRepository');

const storageFile = path.join(__dirname, '..', 'storage', 'users.json');

class UserRepository extends JsonFileRepository {
  constructor() {
    super(storageFile, [
      {
        id: 1,
        username: 'owner',
        password: 'changeMe!',
        fullName: 'Адміністратор',
        email: 'admin@example.com',
        role: 'admin'
      }
    ]);
  }

  async findByUsername(username) {
    const users = await this.getAll();
    return users.find((u) => u.username === username) || null;
  }
}

module.exports = UserRepository;
