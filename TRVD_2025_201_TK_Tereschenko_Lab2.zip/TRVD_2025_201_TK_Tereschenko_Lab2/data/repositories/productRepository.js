const path = require('path');
const JsonFileRepository = require('./jsonFileRepository');

const storageFile = path.join(__dirname, '..', 'storage', 'products.json');

class ProductRepository extends JsonFileRepository {
  constructor() {
    super(storageFile, [
      {
        id: 1,
        title: 'Класичний блейзер',
        description: 'Елегантний крій. Обмежена серія.',
        price: 2300,
        image: '/static/assets/jacket.jpg'
      },
      {
        id: 2,
        title: 'Класична футболка – чорний',
        description: 'Преміум бавовна. Чітка посадка.',
        price: 1000,
        image: '/static/assets/overshirt.jpg'
      },
      {
        id: 3,
        title: 'Класична футболка – біла',
        description: 'База, яка підкреслює статус.',
        price: 1000,
        image: '/static/assets/tee.jpg'
      },
      {
        id: 4,
        title: 'Джоггери – чорний',
        description: 'Oversize силует. Комфорт на щодень.',
        price: 1300,
        image: '/static/assets/jogger.jpg'
      }
    ]);
  }
}

module.exports = ProductRepository;
