const fs = require('fs').promises;
const path = require('path');

class JsonFileRepository {
  /**
   * @param {string} storageFile Absolute path to a JSON file.
   * @param {any} defaultValue Default value written if file does not exist.
   */
  constructor(storageFile, defaultValue = []) {
    this.storageFile = storageFile;
    this.defaultValue = defaultValue;
  }

  async _ensureFile() {
    try {
      await fs.access(this.storageFile);
    } catch {
      await fs.mkdir(path.dirname(this.storageFile), { recursive: true });
      await fs.writeFile(this.storageFile, JSON.stringify(this.defaultValue, null, 2), 'utf8');
    }
  }

  async _read() {
    await this._ensureFile();
    const raw = await fs.readFile(this.storageFile, 'utf8');
    try {
      return JSON.parse(raw || 'null') ?? this.defaultValue;
    } catch {
      // If file corrupted, restore to default
      await this._write(this.defaultValue);
      return this.defaultValue;
    }
  }

  async _write(data) {
    await this._ensureFile();
    const tmp = `${this.storageFile}.tmp`;
    await fs.writeFile(tmp, JSON.stringify(data, null, 2), 'utf8');
    await fs.rename(tmp, this.storageFile);
  }

  async getAll() {
    return await this._read();
  }

  async getById(id) {
    const list = await this._read();
    return list.find((x) => String(x.id) === String(id)) || null;
  }

  async create(entity) {
    const list = await this._read();
    const maxId = list.reduce((m, x) => Math.max(m, Number(x.id) || 0), 0);
    const created = { ...entity, id: maxId + 1 };
    list.push(created);
    await this._write(list);
    return created;
  }

  async update(id, patch) {
    const list = await this._read();
    const idx = list.findIndex((x) => String(x.id) === String(id));
    if (idx === -1) return null;
    list[idx] = { ...list[idx], ...patch, id: list[idx].id };
    await this._write(list);
    return list[idx];
  }

  async delete(id) {
    const list = await this._read();
    const next = list.filter((x) => String(x.id) !== String(id));
    if (next.length === list.length) return false;
    await this._write(next);
    return true;
  }
}

module.exports = JsonFileRepository;
