const UserRepository = require('../data/repositories/userRepository');

class UserService {
  constructor() {
    this.repo = new UserRepository();
  }

  async list() {
    return await this.repo.getAll();
  }

  async get(id) {
    return await this.repo.getById(id);
  }

  async create(input) {
    const username = String(input.username || '').trim();
    const password = String(input.password || '').trim();
    const fullName = String(input.fullName || '').trim();
    const email = String(input.email || '').trim();
    const role = String(input.role || '').trim() || 'user';

    if (!username || !password || !email) {
      throw new Error('Потрібно вказати username, password та email.');
    }

    const existing = await this.repo.findByUsername(username);
    if (existing) {
      throw new Error('Користувач з таким username вже існує.');
    }

    return await this.repo.create({ username, password, fullName, email, role });
  }

  async update(id, input) {
    const patch = {
      username: String(input.username || '').trim(),
      password: String(input.password || '').trim(),
      fullName: String(input.fullName || '').trim(),
      email: String(input.email || '').trim(),
      role: String(input.role || '').trim() || 'user'
    };

    if (!patch.username || !patch.password || !patch.email) {
      throw new Error('Потрібно вказати username, password та email.');
    }

    const current = await this.repo.getById(id);
    if (!current) throw new Error('Користувача не знайдено.');

    if (patch.username !== current.username) {
      const existing = await this.repo.findByUsername(patch.username);
      if (existing) {
        throw new Error('Користувач з таким username вже існує.');
      }
    }

    return await this.repo.update(id, patch);
  }

  async remove(id) {
    return await this.repo.delete(id);
  }

  async authenticate(username, password) {
    const u = await this.repo.findByUsername(String(username || '').trim());
    if (!u) return null;
    if (u.password !== String(password || '')) return null;
    return u;
  }
}

module.exports = UserService;
