const ProductRepository = require('../data/repositories/productRepository');

class ProductService {
  constructor() {
    this.repo = new ProductRepository();
  }

  async list() {
    return await this.repo.getAll();
  }

  async get(id) {
    return await this.repo.getById(id);
  }

  async create(input) {
    const title = String(input.title || '').trim();
    const description = String(input.description || '').trim();
    const price = Number(input.price || 0);
    const image = String(input.image || '').trim();

    if (!title || !price) {
      throw new Error('Потрібно вказати назву та ціну.');
    }

    return await this.repo.create({ title, description, price, image });
  }

  async update(id, input) {
    const title = String(input.title || '').trim();
    const description = String(input.description || '').trim();
    const price = Number(input.price || 0);
    const image = String(input.image || '').trim();

    if (!title || !price) {
      throw new Error('Потрібно вказати назву та ціну.');
    }

    const current = await this.repo.getById(id);
    if (!current) throw new Error('Товар не знайдено.');

    return await this.repo.update(id, { title, description, price, image });
  }

  async remove(id) {
    return await this.repo.delete(id);
  }
}

module.exports = ProductService;
